var score = 0;
var mole = document.querySelector('.mole');
var holes = document.querySelectorAll('.hole');
var scoreBoard = document.createElement('div');
scoreBoard.classList.add('score');
scoreBoard.textContent = 'Score: 0';
document.body.appendChild(scoreBoard);

function randomTime(min, max) {
  return Math.floor(Math.random() * (max - min + 1) + min);
}

function randomHole() {
  var index = Math.floor(Math.random() * holes.length);
  return holes[index];
}

function peep() {
  var time = randomTime(500, 1000);
  var hole = randomHole();

  hole.classList.add('up');
  setTimeout(function() {
    hole.classList.remove('up');
    if (!gameOver) {
      peep();
    }
  }, time);
}

function startGame() {
  score = 0;
  gameOver = false;
  mole.style.display = 'block';
  scoreBoard.textContent = 'Score: 0';
  peep();
  setTimeout(function() {
    gameOver = true;
    mole.style.display = 'none';
    alert('Game Over! Your score: ' + score);
  }, 10000);
}

function bonk(event) {
  if (!event.isTrusted) return; // Prevent cheating by automated clicks
  score++;
  this.classList.remove('up');
  scoreBoard.textContent = 'Score: ' + score;
}

holes.forEach(function(hole) {
  hole.addEventListener('click', bonk);
});
